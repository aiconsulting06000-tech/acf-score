# ACF Sovereignty Check

Outil de calcul du Score de Souveraineté ACF® (Agentic Commerce Framework)

## Stack
- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- Recharts (graphiques)
- jsPDF (génération PDF)

## Installation

```bash
npm install
npm run dev
```

## Déploiement

Deploy sur Vercel en 1 clic.

## Structure

```
/app
  /page.tsx              # Landing page
  /calculator/page.tsx   # Formulaire de calcul
  /results/page.tsx      # Affichage résultats
/components
  /ui                    # Composants réutilisables
  /RadarChart.tsx        # Graphique radar
  /ScoreDisplay.tsx      # Affichage du score
  /PDFGenerator.tsx      # Génération rapport PDF
/lib
  /calculator.ts         # Logique de calcul
  /types.ts              # Types TypeScript
```

## Licence

Propriété de Vincent DORANGE - Agentic Commerce Framework®
