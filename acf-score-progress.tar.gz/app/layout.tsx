import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Score ACF® - Calculateur de Souveraineté | Agentic Commerce Framework',
  description: 'Mesurez votre dépendance aux plateformes en 5 minutes. Calculez gratuitement votre Score de Souveraineté ACF® et obtenez un rapport PDF professionnel.',
  keywords: 'ACF, souveraineté, e-commerce, dépendance plateforme, agentic commerce, audit',
  authors: [{ name: 'Vincent DORANGE' }],
  openGraph: {
    title: 'Score ACF® - Calculateur de Souveraineté',
    description: 'Mesurez votre dépendance aux plateformes en 5 minutes',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="fr" className="scroll-smooth">
      <body className={inter.className}>{children}</body>
    </html>
  )
}
